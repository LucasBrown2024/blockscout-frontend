export { default as guessDataType } from './guessDataType';
