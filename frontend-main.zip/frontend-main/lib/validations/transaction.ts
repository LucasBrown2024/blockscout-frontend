// maybe it depends on the network??

export const TRANSACTION_HASH_REGEXP = /^0x[a-fA-F\d]{64}$/;

export const TRANSACTION_HASH_LENGTH = 66;
