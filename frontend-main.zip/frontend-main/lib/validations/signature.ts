export const SIGNATURE_REGEXP = /^0x[a-fA-F\d]{130}$/;
