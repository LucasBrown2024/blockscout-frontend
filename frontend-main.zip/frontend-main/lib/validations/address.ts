// maybe it depends on the network??

export const ADDRESS_REGEXP = /^0x[a-fA-F\d]{40}$/;

export const ADDRESS_LENGTH = 42;
