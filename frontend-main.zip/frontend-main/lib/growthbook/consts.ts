export const STORAGE_KEY = 'growthbook:experiments';
export const STORAGE_LIMIT = 20;
