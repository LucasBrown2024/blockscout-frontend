class WindowPostMessageStream {
  constructor() {
    return null;
  }
}

export {
  WindowPostMessageStream,
};
