function initializeProvider() {}

export {
  initializeProvider,
};
