declare module 'react-identicons'
