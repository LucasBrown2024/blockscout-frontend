import pino from 'pino-http';

export const httpLogger = pino();
