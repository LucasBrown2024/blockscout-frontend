export const base = {
  avatar: 'https://avatars.githubusercontent.com/u/22130104',
  email: 'tom@ohhhh.me',
  name: 'tom goriunov',
  nickname: 'tom2drum',
};

export const withoutEmail = {
  avatar: 'https://avatars.githubusercontent.com/u/22130104',
  email: null,
  name: 'tom goriunov',
  nickname: 'tom2drum',
};
